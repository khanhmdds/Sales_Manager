/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Admin
 */
public class CheckForm {
//    public static boolean checkEmail(String value){
//        Pattern pattern = Pattern.compile("[a-zA-Z][_]*\\d*@[a-z]");
//        Matcher matcher = pattern.matcher(value);
//        if (!matcher.find()) {
//            return false ;
//        }else {
//            return true ;
//        }
//    }
    
//    public static boolean checkPhoneNumber(String value){
//        Pattern pattern = Pattern.compile("[0][1-9]");
//        Matcher matcher = pattern.matcher(value);
//        if (!matcher.find()) {
//            return false ;
//        }else{
//            return true ;
//        }
//    }
}
